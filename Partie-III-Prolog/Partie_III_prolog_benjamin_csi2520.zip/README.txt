/**
 * 
 * Student : Benjamin Kataliko Viranga
 * Student ID : 8842942
 * CSI2520
 * Projet Intégrateur -  Partie Logique (Prolog)
 * 
 */


How to run the program ?

Using SWI-Prolog, load the program dProgramming.pl :

> [dProgramming].

And use the predicate solveKnapsack(Filename, Value, L_items_list) 

Filename is the file to parse.

> solveKnapsack('p1.txt',Value,L_items_list).

p1.txt est le fichier contenant les données utilisées pour l'entrée du programme.
La sortie du programme p1.sol est créé et ajouté directement dans le meme folder dans lequel ces fichiers
sont exécutés. 

Peu importe le nom du fichier utilisé l'entrée : pour (filename.txt), la solution est (filename.sol) à condition que ce fichier 
contienne les memes données que p1.txt;